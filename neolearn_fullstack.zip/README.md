NEOLEARN - Fullstack Demo

Structure:
- frontend/  (Vite + React + Tailwind demo app)
- backend/   (Node + Express + SQLite demo server)

How to run backend:
cd backend
npm install
npm start

How to run frontend:
cd frontend
npm install
npm run dev

This package is a demo scaffold. Frontend saves progress in localStorage; backend offers simple APIs you can connect to.
