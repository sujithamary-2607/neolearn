import React from 'react'
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import AuthPage from './pages/AuthPage'
import StudentHome from './pages/StudentHome'
import SubjectsList from './pages/SubjectsList'
import SubjectPage from './pages/SubjectPage'
import QuizGame from './pages/games/QuizGame'
import PuzzleGame from './pages/games/PuzzleGame'
import WordHunt from './pages/games/WordHunt'
import MatchingGame from './pages/games/MatchingGame'
import TeacherDashboard from './pages/TeacherDashboard'

export default function App(){
  return (
    <Router>
      <Routes>
        <Route path='/' element={<AuthPage/>} />
        <Route path='/student' element={<StudentHome/>} />
        <Route path='/subjects' element={<SubjectsList/>} />
        <Route path='/subjects/:subId' element={<SubjectPage/>} />
        <Route path='/subjects/:subId/quiz' element={<QuizGame/>} />
        <Route path='/subjects/:subId/puzzle' element={<PuzzleGame/>} />
        <Route path='/subjects/:subId/wordhunt' element={<WordHunt/>} />
        <Route path='/subjects/:subId/matching' element={<MatchingGame/>} />
        <Route path='/teacher' element={<TeacherDashboard/>} />
      </Routes>
    </Router>
  )
}
