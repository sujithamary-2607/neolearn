import React from 'react'
import { Link } from 'react-router-dom'
const SUBJECTS = [{id:'science',title:'Science'},{id:'tech',title:'Technology'},{id:'engg',title:'Engineering'},{id:'math',title:'Mathematics'}]
export default function SubjectsList(){ return (
  <div className="p-6 max-w-4xl mx-auto">
    <h3 className="text-xl font-bold">Subjects</h3>
    <div className="mt-4 grid grid-cols-2 gap-4">
      {SUBJECTS.map(s=> <Link key={s.id} to={`/subjects/${s.id}`} className="p-4 border rounded hover:shadow">{s.title}</Link>)}
    </div>
  </div>
)}