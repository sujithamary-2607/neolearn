import React, {useState} from 'react'
import { useParams } from 'react-router-dom'
export default function WordHunt(){
  const { subId } = useParams()
  const [found,setFound]=useState([])
  const words = ['ATOM','CELL','FORCE']
  function mark(w){ if (!found.includes(w)) setFound(f=>[...f,w]) }
  return (
    <div className="p-6">
      <h3 className="font-bold">Word Hunt — {subId}</h3>
      <p className="mt-2 text-sm">Tap words below to mark found.</p>
      <div className="mt-4 grid grid-cols-3 gap-2">{words.map(w=>(<button key={w} onClick={()=>mark(w)} className={`p-3 rounded ${found.includes(w)? 'bg-green-300':'bg-slate-100'}`}>{w}</button>))}</div>
    </div>
  )
}
