import React, {useState} from 'react'
import { useParams } from 'react-router-dom'
export default function PuzzleGame(){
  const { subId } = useParams()
  const items0 = ['Step 1','Step 2','Step 3']
  const [items,setItems] = useState(items0.slice().sort(()=>Math.random()-0.5))
  function check(){ if (items.join('|')===items0.join('|')) alert('Solved!') else alert('Try again') }
  return (
    <div className="p-6">
      <h3 className="font-bold">Puzzle — {subId}</h3>
      <div className="mt-4 grid gap-2">{items.map((it,i)=>(<div key={i} className="p-2 border rounded">{it}</div>))}</div>
      <div className="mt-3 flex gap-2"><button onClick={()=>setItems(items0.slice().sort(()=>Math.random()-0.5))} className="px-3 py-1 rounded bg-slate-200">Shuffle</button><button onClick={check} className="px-3 py-1 rounded bg-blue-600 text-white">Check</button></div>
    </div>
  )
}
