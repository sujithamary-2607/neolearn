import React, {useState} from 'react'
import { useParams } from 'react-router-dom'
export default function QuizGame(){
  const { subId } = useParams()
  const sampleQ = [{q:'What is H2O?', opts:['Water','Oxygen','Hydrogen'], ans:0},{q:'2+2=?', opts:['3','4','5'], ans:1}]
  const [idx,setIdx]=useState(0), [score,setScore]=useState(0)
  const user = JSON.parse(sessionStorage.getItem('neolearn_user')||'null')
  function answer(i){
    if (i===sampleQ[idx].ans) setScore(s=>s+1)
    if (idx < sampleQ.length-1) setIdx(idx+1)
    else {
      const prog = JSON.parse(localStorage.getItem('neolearn_progress_v1')||'{}')
      const p = prog[user.name] || {}
      p.subjects = p.subjects||{}
      p.subjects[subId] = p.subjects[subId]||{score:0,games:[]}
      p.subjects[subId].score += score
      p.subjects[subId].games.push('quiz')
      p.streak = (p.streak||0)+1
      prog[user.name] = p
      localStorage.setItem('neolearn_progress_v1', JSON.stringify(prog))
      alert('Quiz finished! Score: '+score)
    }
  }
  return (
    <div className="p-6">
      <h3 className="font-bold">Quiz — {subId}</h3>
      <div className="mt-4 p-4 border rounded">
        <div className="font-semibold">Q: {sampleQ[idx].q}</div>
        <div className="mt-3 grid gap-2">{sampleQ[idx].opts.map((o,i)=>(<button key={i} onClick={()=>answer(i)} className="p-2 border rounded text-left">{o}</button>))}</div>
      </div>
    </div>
  )
}
