import React from 'react'
import { useParams } from 'react-router-dom'
export default function MatchingGame(){
  const { subId } = useParams()
  const pairs = [['Sun','Star'], ['Earth','Planet']]
  return (
    <div className="p-6">
      <h3 className="font-bold">Matching — {subId}</h3>
      <div className="mt-4 grid grid-cols-2 gap-2">{pairs.map((p,i)=>(<div key={i} className="p-3 border rounded">{p.join(' — ')}</div>))}</div>
    </div>
  )
}
