import React from 'react'
import { Link, useNavigate } from 'react-router-dom'

const SUBJECTS = [{id:'science',title:'Science'},{id:'tech',title:'Technology'},{id:'engg',title:'Engineering'},{id:'math',title:'Mathematics'}]

export default function StudentHome(){
  const user = JSON.parse(sessionStorage.getItem('neolearn_user')||'null')
  const prog = JSON.parse(localStorage.getItem('neolearn_progress_v1')||'{}')[user?.name] || {}
  const navigate = useNavigate()
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-green-50">
      <div className="p-4 bg-white/80 shadow flex justify-between">
        <div className="flex items-center gap-3"><img src="/logo.png" className="h-10" alt="logo"/><div><div className="font-bold">NEOLEARN</div><div className="text-xs">{user?.name}</div></div></div>
        <div className="flex gap-2">
          <Link to="/subjects" className="px-3 py-1 bg-slate-100 rounded">Subjects</Link>
        </div>
      </div>
      <div className="p-6 max-w-6xl mx-auto">
        <h3 className="text-2xl font-bold">Hello, {user?.name}</h3>
        <p className="text-sm text-slate-600">Grade: {user?.grade} — Streak: {prog?.streak || 0}</p>
        <div className="mt-6 grid grid-cols-2 gap-4">
          {SUBJECTS.map(s=>(
            <div key={s.id} className="p-4 rounded border cursor-pointer" onClick={()=>navigate(`/subjects/${s.id}`)}>
              <div className="font-semibold">{s.title}</div>
              <div className="text-xs text-slate-500 mt-2">Games: Quiz · Puzzle · Word Hunt · Matching</div>
            </div>
          ))}
        </div>
        <div className="mt-6 bg-white p-4 rounded shadow">
          <h4 className="font-bold">Scholarships & Guidance</h4>
          <p className="text-sm text-slate-600 mt-2">After grade 12 students can explore curated scholarships and mentorship.</p>
        </div>
      </div>
    </div>
  )
}
