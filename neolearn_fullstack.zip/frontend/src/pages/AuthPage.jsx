import React, {useState} from 'react'
import { useNavigate } from 'react-router-dom'

export default function AuthPage(){
  const [name,setName]=useState('')
  const [role,setRole]=useState('student')
  const [lang,setLang]=useState('eng')
  const navigate = useNavigate()

  function submit(e){
    e.preventDefault()
    sessionStorage.setItem('neolearn_user', JSON.stringify({name, role, lang, grade:6}))
    // initialize localStorage progress
    const raw = localStorage.getItem('neolearn_progress_v1')
    const prog = raw ? JSON.parse(raw) : {}
    if (!prog[name]) prog[name] = { name, role, lang, grade:6, badges:[], certificates:[], streak:0, subjects:{} }
    localStorage.setItem('neolearn_progress_v1', JSON.stringify(prog))
    if (role==='teacher') navigate('/teacher')
    else navigate('/student')
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-400 to-green-300 p-6">
      <div className="w-full max-w-md bg-white/90 rounded-2xl shadow-lg p-6">
        <h2 className="text-2xl font-bold text-center">NEOLEARN</h2>
        <p className="text-center text-sm">Learn · Play · Grow</p>
        <form onSubmit={submit} className="mt-6 space-y-4">
          <input required placeholder="Your name" value={name} onChange={e=>setName(e.target.value)} className="w-full p-2 border rounded" />
          <div className="flex gap-2">
            <button type="button" onClick={()=>setRole('student')} className={role==='student'?'bg-blue-600 text-white p-2 rounded':'p-2 rounded bg-slate-100'}>Student</button>
            <button type="button" onClick={()=>setRole('teacher')} className={role==='teacher'?'bg-blue-600 text-white p-2 rounded':'p-2 rounded bg-slate-100'}>Teacher</button>
          </div>
          <select value={lang} onChange={e=>setLang(e.target.value)} className="w-full p-2 border rounded">
            <option value="eng">English</option>
            <option value="hindi">हिंदी</option>
            <option value="tam">தமிழ்</option>
          </select>
          <div className="flex justify-end">
            <button className="px-4 py-2 bg-blue-700 text-white rounded">Continue</button>
          </div>
        </form>
      </div>
    </div>
  )
}
