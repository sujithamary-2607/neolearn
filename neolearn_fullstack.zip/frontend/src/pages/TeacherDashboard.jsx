import React from 'react'
export default function TeacherDashboard(){
  const user = JSON.parse(sessionStorage.getItem('neolearn_user')||'null')
  const data = JSON.parse(localStorage.getItem('neolearn_progress_v1')||'{}')
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-green-50 p-6">
      <div className="max-w-6xl mx-auto mt-6">
        <h3 className="text-2xl font-bold">Teacher Dashboard</h3>
        <p className="text-sm text-slate-600">Class overview (local demo).</p>
        <div className="mt-4 grid gap-4">
          {Object.keys(data).length ? Object.values(data).map((st,i)=>(<div key={i} className="p-3 border rounded"><div className="font-semibold">{st.name}</div><div className="text-xs text-slate-600">Streak: {st.streak||0} — Subjects: {Object.keys(st.subjects||{}).join(', ')||'—'}</div></div>)) : <div className="text-sm text-slate-500">No student data yet.</div>}
        </div>
      </div>
    </div>
  )
}
