import React from 'react'
import { useParams, useNavigate } from 'react-router-dom'
export default function SubjectPage(){
  const { subId } = useParams()
  const navigate = useNavigate()
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-green-50">
      <div className="p-4 bg-white/80 shadow flex justify-between"><div className="font-bold">NEOLEARN</div></div>
      <div className="p-6 max-w-4xl mx-auto">
        <div className="flex justify-between items-center"><h3 className="text-2xl font-bold">{subId}</h3><div className="text-sm text-slate-600">Progress: 0% — Score: 0</div></div>
        <div className="mt-6 grid grid-cols-3 gap-4">
          <div onClick={()=>navigate(`/subjects/${subId}/quiz`)} className="p-4 border rounded cursor-pointer">Quiz</div>
          <div onClick={()=>navigate(`/subjects/${subId}/puzzle`)} className="p-4 border rounded cursor-pointer">Puzzle</div>
          <div onClick={()=>navigate(`/subjects/${subId}/wordhunt`)} className="p-4 border rounded cursor-pointer">Word Hunt</div>
          <div onClick={()=>navigate(`/subjects/${subId}/matching`)} className="p-4 border rounded cursor-pointer">Matching</div>
        </div>
      </div>
    </div>
  )
}
