const express = require('express')
const cors = require('cors')
const bodyParser = require('body-parser')
const sqlite3 = require('sqlite3').verbose()
const path = require('path')

const app = express()
app.use(cors())
app.use(bodyParser.json())

const DB_FILE = path.join(__dirname,'neolearn.db')
const db = new sqlite3.Database(DB_FILE)

db.serialize(()=>{
  db.run(`CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, name TEXT UNIQUE, role TEXT, lang TEXT, grade INTEGER)`)
  db.run(`CREATE TABLE IF NOT EXISTS progress (id INTEGER PRIMARY KEY, user TEXT, data TEXT)`)
})

// simple endpoints
app.post('/api/register', (req,res)=>{
  const {name, role, lang, grade} = req.body
  db.run('INSERT OR IGNORE INTO users (name,role,lang,grade) VALUES (?,?,?,?)', [name,role,lang,grade||6], function(err){
    if (err) return res.status(500).json({error:err.message})
    res.json({ok:true, id:this.lastID})
  })
})

app.get('/api/users', (req,res)=>{
  db.all('SELECT * FROM users', [], (err,rows)=>{ if (err) return res.status(500).json({error:err.message}); res.json(rows) })
})

app.post('/api/progress', (req,res)=>{
  const {user, data} = req.body
  db.run('INSERT INTO progress (user, data) VALUES (?,?)', [user, JSON.stringify(data)], function(err){
    if (err) return res.status(500).json({error:err.message})
    res.json({ok:true, id:this.lastID})
  })
})

app.get('/api/progress/:user', (req,res)=>{
  const u = req.params.user
  db.all('SELECT * FROM progress WHERE user = ? ORDER BY id DESC', [u], (err,rows)=>{ if (err) return res.status(500).json({error:err.message}); res.json(rows) })
})

const PORT = process.env.PORT || 4000
app.listen(PORT, ()=>console.log('Server running on', PORT))
