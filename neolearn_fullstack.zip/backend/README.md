NEOLEARN Backend (Node + Express + SQLite)

How to run:
1. cd backend
2. npm install
3. npm start

APIs:
- POST /api/register  {name, role, lang, grade}
- GET  /api/users
- POST /api/progress  {user, data}
- GET  /api/progress/:user
